<!-- after user click one of the link in test.php -->
<?php
  // start session
  session_start();

  if (!isset($_SESSION['email']) || empty($_SESSION['email'])) {
    echo "<script type='text/javascript'>
            alert('You are trying to access member-only content.\\nPlease login to continue.');
            window.top.location = 'member-corner.html';
          </script>";

    return;
  }
?>

<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
  </head>
  <body>
    <div class="row">
      <div class="col-md-4">
        <button class="btn btn-secondary" type="button" onclick="goBack()">Go Back</button>
      </div>
      <script type="text/javascript">
        function goBack(){
          window.history.back();
        }
      </script>
      <div class="col-md-4">
        <?php
          $conn = mysqli_connect('localhost','heansolu_roadrules_admin','ue6Y9tZMTR56jLW5','heansolu_roadrules');//might need to change

          //let us know if connected to database
          if (!$conn) {
            echo "Could not connect to database.<br>";
            echo "Error Number: ".mysqli_connect_errno()."<br>";
            echo "Error: ".mysqli_connect_error();
          }else {
              if (isset($_GET['choose'])) {

                //if bahagian A is clicked
                if ($_GET['choose'] == 0) {
                  //send this query
                  $query = "SELECT * FROM bhgA";
                }
                //if bahagian B is clicked
                elseif($_GET['choose'] == 1) {
                  //send this query
                  $query = "SELECT * FROM bhgB";
                }
                //if bahagian C clicked
                elseif ($_GET['choose'] == 2) {
                  //send this query
                  $query = "SELECT * FROM bhgC";
                }

                //check if query is success
                if (!mysqli_query($conn,$query)) {
                  echo "Query unsuccessfull".mysqli_error();
                  echo "Query: ".$query;

                }else {
                  //array to store every data in a row
                  $rowList = array();
                  $i = $j = 0;
                  //run this Query
                  $r = mysqli_query($conn,$query);

                  //retrieve every row of data
                  while ($row = mysqli_fetch_array($r)) {
                    //store every column
                    $rowList[$i] = array($row['quest_id'],//$j = 0
                                        $row['question'],//$j = 1
                                        $row['opt_1']   ,//$j = 2
                                        $row['opt_2']   ,//$j = 3
                                        $row['opt_3']   ,//$j = 4
                                        $row['ans'])    ;//$j = 5
                    $i++;
                  }
                  //to decide the structure of question based on different bahagian
                  //if it is bahagian B or C
                  if ($_GET['choose'] !=0 ) {
                  ?>
                    <form action="test_result.php" method="post">
                      <!-- Decide to display bahagian B or Bahagia C -->
                      <?php echo ($_GET['choose'] ==1 )?"<h1 style=\"text-align:center\">Bahagian B</h1>":"<h1 style=\"text-align:center\">Bahagian C</h1>"; ?>
                      <br>
                      <?php for ($i=0; $i < count($rowList); $i++) { ?>
                        <!-- QUESTS -->
                        <h3><?php echo $rowList[$i][$j+1]; ?></h3>
                        <!-- OPTS -->
                        <label for="opt<?php echo $i;?>_1">
                          <input type="radio" name="q<?php echo $i+1; ?>" id="opt<?php echo $i;?>_1" value="<?php echo $rowList[$i][$j+2] ?>">
                          <?php echo $rowList[$i][$j+2] ?>
                        </label>
                        <br>
                        <label for="opt<?php echo $i;?>_2">
                          <input type="radio" name="q<?php echo $i+1; ?>" id="opt<?php echo $i;?>_2" value="<?php echo $rowList[$i][$j+3] ?>">
                          <?php echo $rowList[$i][$j+3] ?>
                        </label>
                        <br>
                        <label for="opt<?php echo $i;?>_3">
                          <input type="radio" name="q<?php echo $i+1; ?>" id="opt<?php echo $i;?>_3" value="<?php echo $rowList[$i][$j+4] ?>">
                          <?php echo $rowList[$i][$j+4] ?>
                        </label>
                        <hr>
                      <?php
                      }//end for loop
                      ?>
                      <input type="hidden" name="bhg" value="<?php echo $_GET['choose']; ?>">
                      <input class="btn btn-success" type="submit" value="Submit">
                    </form>
                  <?php
                }else{//bahagian A
                  //get the image source to display
                  //10th-15th and 24th value in array is empty, because it will be taken from db
                  $img_src = array("images/a_set1_1.png","images/a_set1_2.png","images/a_set1_3.png","images/a_set1_4.png","images/a_set1_5.png",
                                  "images/a_set1_6.png","images/a_set1_7.png","images/a_set1_8.png","images/a_set1_9.png","","","","","","",
                                  "images/a_set1_16.png","images/a_set1_17.png","images/a_set1_18.png","images/a_set1_19.png","images/a_set1_20.png",
                                  "images/a_set1_21.png","images/a_set1_22.png","images/a_set1_23.png","","images/a_set1_25.png");
                ?>
                  <form action="test_result.php" method="post">
                    <h1 style="text-align:center">Bahagian A</h1>
                    <br>
                    <?php for ($i=0; $i < count($rowList); $i++) {

                      //decide format of display the question for some questions
                      if ($i==9||$i==10||$i==11||$i==12||$i==13||$i==14||$i==23) {
                        ?>
                        <!-- QUESTS -->
                        <h3><?php echo $rowList[$i][$j+1]; ?></h3>
                        <!-- OPTS -->
                        <label for="opt<?php echo $i; ?>_1">
                          <input type="radio" name="q<?php echo $i+1; ?>" id="opt<?php echo $i; ?>_1" value="<?php echo $rowList[$i][$j+2] ?>">
                          <img src="<?php echo $rowList[$i][$j+2]; ?>" alt="option 1">
                        </label>
                        <label for="opt<?php echo $i; ?>_2">
                          <input type="radio" name="q<?php echo $i+1; ?>" id="opt<?php echo $i; ?>_2" value="<?php echo $rowList[$i][$j+3] ?>">
                          <img src="<?php echo $rowList[$i][$j+3]; ?>" alt="option 2">
                        </label>
                        <label for="opt<?php echo $i; ?>_3">
                          <input type="radio" name="q<?php echo $i+1; ?>" id="opt<?php echo $i; ?>_3" value="<?php echo $rowList[$i][$j+4] ?>">
                          <img src="<?php echo $rowList[$i][$j+4]; ?>" alt="option 3">
                        </label>
                        <hr>
                        <?php
                      }else{
                      ?>
                      <!-- QUESTS -->
                      <h3><?php echo $rowList[$i][$j+1]; ?></h3>
                      <img src="<?php echo $img_src[$i]; ?>" alt="Q<?php echo $i+1; ?>">
                      <br>
                      <!-- OPTS -->
                      <label for="opt<?php echo $i; ?>_1">
                        <input type="radio" name="q<?php echo $i+1; ?>" id="opt<?php echo $i; ?>_1" value="<?php echo $rowList[$i][$j+2] ?>">
                        <?php echo $rowList[$i][$j+2]; ?>
                      </label>
                      <br>
                      <label for="opt<?php echo $i; ?>_2">
                        <input type="radio" name="q<?php echo $i+1; ?>" id="opt<?php echo $i; ?>_2" value="<?php echo $rowList[$i][$j+3] ?>">
                        <?php echo $rowList[$i][$j+3]; ?>
                      </label>
                      <br>
                      <label for="opt<?php echo $i; ?>_3">
                        <input type="radio" name="q<?php echo $i+1; ?>" id="opt<?php echo $i; ?>_3" value="<?php echo $rowList[$i][$j+4] ?>">
                        <?php echo $rowList[$i][$j+4]; ?>
                      </label>
                      <hr>
                      <?php
                      }
                    } //end for loop
                    ?>
                    <br><br>
                    <input type="hidden" name="bhg" value="<?php echo $_GET['choose']; ?>">
                    <input class="btn btn-success"type="submit" value="Submit">
                  </form>
                <?php
                }
              }//end else
            }//end if
          }//end else
        mysqli_close($conn);
        ?>
    </div>
    <div class="col-md-4"></div>
  </div>
</body>
</html>
