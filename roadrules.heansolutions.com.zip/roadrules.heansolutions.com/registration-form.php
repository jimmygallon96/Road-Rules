<?php

  // start the session
  session_start();

  if (isset($_SESSION['email']) && !empty($_SESSION['email'])) {

    echo "<script type='text/javascript'>
            window.top.location = 'member-corner.html';
          </script>'";
  }

  if (isset($_POST['submitted']) && $_POST['submitted'] == 'true') {

      // set submitted value = false
      $_POST['submitted'] = 'false';

      // Condition 0: Name, Email and Password, and Confirm password are empty
      if (
        empty($_POST['name']) && empty($_POST['email']) &&
        empty($_POST['password01']) && empty($_POST['password02'])
      ) {

        echo "<script type='text/javascript'>
                alert('Fields cannot empty.');
                window.history.back();
              </script>";

      // Condition 1: Email is empty
      } else if (!isset($_POST['name']) || empty($_POST['name'])) {

          echo "<script type='text/javascript'>
                  alert('Please enter your name.');
                  window.history.back();
                </script>";

      // Condition 2: Email is empty
      } else if (!isset($_POST['email']) || empty($_POST['email'])) {

      echo "<script type='text/javascript'>
              alert('Please enter your email.');
              window.history.back();
            </script>";

      // Condition 3: password is empty
      } else if (!isset($_POST['password01']) || empty($_POST['password01'])) {

          echo "<script type='text/javascript'>
                  alert('Please enter your password.');
                  window.history.back();
                </script>";

        // Condition 4: confirm the password
      } else if (!isset($_POST['password02']) || empty($_POST['password02'])) {

          echo "<script type='text/javascript'>
                  alert('Please confirm your password.');
                  window.history.back();
                </script>";


        // Condition 5: passwords do not match
      } else if ($_POST['password01'] != $_POST['password02']) {

          echo "<script type='text/javascript'>
                  alert('Passwords do not match. Please check again.');
                  window.history.back();
                </script>";

      }  else {

        require('include/Register.php');
        register($_POST['name'], $_POST['email'], $_POST['password01']);
      }

  } else {
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Register a new Account</title>
    <style>

      body {
        width: 99%;
      }

      table {
        width: 99%;
      }

      .label {
          font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
          font-size: 20px;
          margin-right: 50px;
      }

      .textbox {
        padding: 5px;
        font-size: 18px;
        width: 220px;
        border-radius: 5px;
      }

      .login {
        background: #6c98d1;
      }

      .login:hover {

        background: #597ba8;
      }

      .register {

        color: #FFF;
        padding: 10px;
        font-size: 20px;
        min-width: 235px;
        font-weight: bold;
        margin-right: 50px;
        border-radius: 5px;
        background: #79d36b;
      }
    </style>
  </head>
  <body style="text-align: center;">
    <form action="registration-form.php" method="post">
      <table>
        <tr>
          <td style="text-align: right; width: 45%;">
            <p class="label">Name:</p>
          </td>
          <td style="text-align: left; width: 55%;">
            <input type="text" name="name" class="textbox">
          </td>
        </tr>
        <tr>
          <td style="text-align: right; width: 45%;">
            <p class="label">Email:</p>
          </td>
          <td style="text-align: left; width: 55%;">
            <input type="email" name="email" class="textbox">
          </td>
        </tr>
        <tr>
          <td style="text-align: right; width: 45%;">
            <p class="label">Password:</p>
          </td>
          <td style="text-align: left; width: 55%;">
            <input type="password" name="password01" class="textbox">
          </td>
        </tr>
        <tr>
          <td style="text-align: right; width: 45%;">
            <p class="label">Confirm password:</p>
          </td>
          <td style="text-align: left; width: 55%;">
            <input type="password" name="password02" class="textbox">
          </td>
        </tr>
        <tr>
          <td colspan="2" width="100%">
            <input type="hidden" name="submitted" value="true">
          </td>
        </tr>
        <tr>
          <td style="width: 45%;">
            <p>&nbsp;</p>
          </td>
          <td style="text-align: left; width: 55%;">
              <input type="submit" value="Register" class="register">
          </td>
        </tr>
      </table>
    </form>
  </body>
</html>

<?php
  }
?>
