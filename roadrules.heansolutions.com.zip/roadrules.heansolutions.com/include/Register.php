<?php

  function register($name, $email, $password) {

    // check whether connection to database is successful
    $conn = mysqli_connect('localhost', 'heansolu_roadrules_admin', 'ue6Y9tZMTR56jLW5');

    if ($conn) {

      // select database
      mysqli_select_db($conn, 'heansolu_roadrules');

      // query
      $query = "INSERT INTO user (id, name, email, password) VALUES(Null, '$name', '$email', '$password');";

      // get the result
      $result = mysqli_query($conn, $query);

      // get the status
      $status = mysqli_affected_rows($conn);

      // close connection
      mysqli_close($conn);

      if ($status == 1) {

        // save name, email and password in session
        $_SESSION["name"] = $name;
        $_SESSION["email"] = $email;
        $_SESSION["password"] = $password;

        echo "<script type='text/javascript'>
                alert('Registered successfully.');
                window.top.location = 'member-corner.html';
              </script>";

      } else {

        echo "<script type='text/javascript'>
                alert('User exists.');
                window.history.back();
              </script>";
      }

    } else {

      echo "<script type='text/javascript'>
              alert('Error: Could not connect to database..');
              window.history.back();
            </script>";
    }
  }

?>
