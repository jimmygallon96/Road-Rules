<?php

  function getImagesArray($table) {

    // check whether connection to database is successful
    $conn = mysqli_connect('localhost', 'heansolu_roadrules_admin', 'ue6Y9tZMTR56jLW5');

    if ($conn) {
      // select database
      mysqli_select_db($conn, 'heansolu_roadrules');

      // query
      $query = "SELECT * FROM $table;";

      // get the result
      $result = mysqli_query($conn, $query);

      $imagesArray = array();
      $i = 0;

      while ($row = mysqli_fetch_array($result)) {

          $imagesArray[$i] = $row['image'];
          $i++;
      }

      // close the database connection
      mysqli_close($conn);

      // return the imagesArray
      return $imagesArray;

    } else {

      return NULL;
    }
  }

?>
