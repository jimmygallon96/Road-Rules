<?php

//start session
session_start();

// remove all session variables
session_unset();

// destroy the session
session_destroy();

echo "<script type='text/javascript'>
        alert('You are now Logged out.');
        window.history.back();
      </script>";
?>
