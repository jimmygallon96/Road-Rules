<?php

  function login($email, $password) {

    // check whether connection to database is successful
    $conn = mysqli_connect('localhost', 'heansolu_roadrules_admin', 'ue6Y9tZMTR56jLW5');

    if ($conn) {

      // select database
      mysqli_select_db($conn, 'heansolu_roadrules');

      // query
      $query = "SELECT name, email, password FROM user WHERE email = '$email' AND password = '$password';";

      // get the result
      $result = mysqli_query($conn, $query);

      // get number of rows
      $rowCount = mysqli_num_rows($result);

      if ($rowCount > 0) {

        $row = mysqli_fetch_array($result);

        // close connection
        mysqli_close($conn);

        // save name, email and password in session
        $_SESSION["name"] = $row['name'];
        $_SESSION["email"] = $row['email'];
        $_SESSION["password"] = $row['password'];

        echo "<script type='text/javascript'>
                alert('You are now Logged in.');
                window.top.location = 'index.html';
              </script>";

        exit();

      } else {

        echo "<script type='text/javascript'>
                alert('Incorrect email or password.');
                window.history.back();
              </script>";
      }

    } else {

      echo "<script type='text/javascript'>
              alert('Error: Could not connect to database..');
              window.history.back();
            </script>";
    }
  }

?>
