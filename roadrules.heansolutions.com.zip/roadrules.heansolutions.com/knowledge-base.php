<!DOCTYPE html>
<html>
  <head>
    <style>
    .vertical-menu {
        width: 30%;
    }

    .item {
        color: black;
        display: block;
        padding: 12px;
        text-decoration: none;
        background-color: #CCC;
        border-bottom: 1px solid #EEE;
    }

    .sub-item {
        color: black;
        padding: 10px;
        display: block;
        text-decoration: none;
        background-color: #DDD;
    }

    .vertical-menu a:hover {
        background-color: #ccc;
    }

    .vertical-menu a.active {
        color: white;
        background-color: #4CAF50;
    }
    </style>
  </head>

  <body>
    <div style="height: 99%; width: 99%; display: flex;">
      <div class="vertical-menu">

        <a class="item">Traffic Signs</a>
        <div id="itemlist1">
          <?php

            $titleArray = array(
              0 => 'Danger Traffic Signs',
              1 => 'Prohibitive Traffic Signs',
              2 => 'Mandatory Traffic Signs',
              3 => 'Informative Traffic Signs',
              4 => 'Temporary Traffic Signs',
              5 => 'Lines On The Road',
              6 => 'Traffic Police Hand Signs and Signals',
              7 => "Motorist's /Motorcyclist's Hand Signals"
            );

            if (!isset($_GET['page'])) {
              $_GET['page'] = 0;
            }

            foreach ($titleArray as $position => $title) {

              if ($_GET['page'] == $position) {
                echo "<a href='knowledge-base.php?page=".$position."' class='sub-item active'>".$titleArray[$position]."</a>";
              } else {
                echo "<a href='knowledge-base.php?page=".$position."' class='sub-item'>".$titleArray[$position]."</a>";
              }
            }
          ?>
        </div>
      </div>

      <div style="width: 70%; background: #CDD; border-left: 1px solid #EEE;">
        <?php
          require('include/ImageManager.php');

          switch ($_GET['page']) {

            case 0:
              $imageArray = getImagesArray('dangerTrafficSigns');
              break;

            case 1:
              $imageArray = getImagesArray('prohibitiveTrafficSigns');
              break;

            case 2:
              $imageArray = getImagesArray('mandatoryTrafficSigns');
              break;

            case 3:
              $imageArray = getImagesArray('informativeTrafficSigns');
              break;

            case 4:
              $imageArray = getImagesArray('temporaryTrafficSigns');
              break;

            case 5:
              $imageArray = getImagesArray('lineOnTheRoad');
              break;

            case 6:
              $imageArray = getImagesArray('TPHSaS');
              break;

            case 7:
              $imageArray = getImagesArray('MMHS');
              break;
          }

          for ($i = 0; $i < sizeof($imageArray); $i++) {
            echo "<p style='text-align: left; margin-left: 20px;'>
                    <img src='images/".$imageArray[$i]."' height='150px;' width='auto;' ><br>
                  </p>";
          }
        ?>
      </div>
  </div>
  </body>
</html>
