<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
  </head>
  <body>
    <h2 style="text-align:center">We have provided some small tests to test your knowledge.</h2>
    <div class="row">
      <div class="col-md-3"></div>
    <!-- loop three choice of bahagian -->
    <?php
      //array to loop throught the image and its description
      $img_src = array("images/choose_bhga.jpg","images/choose_bhgb.jpg","images/choose_bhgc.jpg");
      $img_alt = array("bhg a", "bhg b", "bhg c");
      $img_descrpt = array("<b>Bahagian A</b> is to test your understanding on symbol or the sign board on the road",
                           "<b>Bahagian B</b> is to test your understanding about the rules on the road",
                           "<b>Bahagian C</b> is to test your understanding about the road, laws and questions about KEJARA");
      for ($i=0; $i < 3; $i++) {
    ?>
      <div class="col-md-2 border border-primary rounded" style="margin:10px;background-color:white">
        <a class=""  href="bhg.php?choose=<?php echo $i; ?>">
          <figure >
            <img class="img-responsive"src="<?php echo $img_src[$i]; ?>" alt="<?php echo $img_alt[$i]; ?>">
            <figcaption><?php echo $img_descrpt[$i]; ?></figcaption>
          </figure>
        </a>
      </div>
    <?php
    }//end for loop
    ?>
    <div class="col-md-3"></div>
    </div>
  </body>
</html>
