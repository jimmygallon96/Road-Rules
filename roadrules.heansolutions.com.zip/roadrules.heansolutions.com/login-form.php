<?php

  // start the session
  session_start();

  if (isset($_SESSION['email']) && !empty($_SESSION['email'])) {

    $name = $_SESSION['name'];
    $email = $_SESSION['email'];
?>
  <!DOCTYPE html>
  <html>
    <head>
      <style>
        .logout:hover {

          background: #c6054d;
        }

        .logout {

          color: #FFF;
          padding: 10px;
          font-size: 15px;
          font-weight: bold;
          border-radius: 5px;
          background: #e21460;
        }
      </style>
    </head>
    <body>
      <p>Name: <?php echo $name; ?></p>
      <p>Email: <?php echo $email; ?></p>
      <a href="include/logout.php">
        <input type="button" id="logout" value="Log out" class="logout">
      </a>
    </body>
  </html>

<?php

  return;
  }

  if (isset($_POST['submitted']) && $_POST['submitted'] == 'true') {

      // set submitted value = false
      $_POST['submitted'] = 'false';

      // Condition 1: Email and Password are empty
      if (empty($_POST['email']) && empty($_POST['password'])) {

        echo "<script type='text/javascript'>
                alert('Fields cannot empty.');
                window.history.back();
              </script>";

      // Condition 2: Email is empty
      } else if (!isset($_POST['email']) || empty($_POST['email'])) {

        echo "<script type='text/javascript'>
                alert('Please enter your email.');
                window.history.back();
              </script>";

      // Condition 3: password is empty
      } else if (!isset($_POST['password']) || empty($_POST['password'])) {

        echo "<script type='text/javascript'>
                alert('Please enter your password.');
                window.history.back();
              </script>";

      } else {

        require('include/Login.php');

        login($_POST['email'], $_POST['password']);
      }

  } else {
?>

<!DOCTYPE html>
<html>
  <head>
    <title>Login</title>
    <style>

      body {
        width: 99%;
      }

      table {
        width: 99%;
      }

      .label {
          font-family: "Lucida Sans Unicode", "Lucida Grande", sans-serif;
          font-size: 20px;
          margin-right: 50px;
      }

      .textbox {
        padding: 5px;
        font-size: 18px;
        width: 220px;
        border-radius: 5px;
      }

      .login {
        color: #FFF;
        padding: 10px;
        font-size: 20px;
        min-width: 235px;
        font-weight: bold;
        margin-right: 50px;
        border-radius: 5px;
        background: #6c98d1;
      }

      .login:hover {

        background: #597ba8;
      }

      .register {

        color: #FFF;
        padding: 10px;
        font-size: 20px;
        font-weight: bold;
        border-radius: 5px;
        background: #79d36b;
      }
    </style>
  </head>
  <body style="text-align: center;">
    <form action="login-form.php" method="post">
      <table>
        <tr>
          <td style="text-align: right; width: 45%;">
            <p class="label">Email:</p>
          </td>
          <td style="text-align: left; width: 55%;">
            <input type="email" name="email" class="textbox">
          </td>
        </tr>
        <tr>
          <td style="text-align: right; width: 45%;">
            <p class="label">Password:</p>
          </td>
          <td style="text-align: left; width: 55%;">
            <input type="password" name="password" class="textbox">
          </td>
        </tr>
        <tr>
          <td colspan="2" width="100%">
            <input type="hidden" name="submitted" value="true">
          </td>
        </tr>
        <tr>
          <td style="width: 45%;">
            <p>&nbsp;</p>
          </td>
          <td style="text-align: left; width: 55%;">
              <input type="submit" value="Log In" class="login">
          </td>
        </tr>
      </table>
      <br>
      <a href="registration-form.html" target="_blank" style="margin-left: 100px;">Not registered yet? register now!</a>
    </form>
  </body>
</html>

<?php
  }
?>
