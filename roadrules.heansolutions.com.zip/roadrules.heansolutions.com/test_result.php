<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
  </head>
  <body>
    <div class="row">
      <div class="col-md-4">
        <button class="btn btn-secondary" type="button" onclick="goBack()">Go Back</button>
      </div>
      <script type="text/javascript">
        function goBack(){
          window.history.back();
        }
      </script>
      <div class="col-md-4">
        <?php
          $conn = mysqli_connect('localhost','heansolu_roadrules_admin','ue6Y9tZMTR56jLW5','heansolu_roadrules');//might need to change

          if (!$conn) {//if fail to connect
            echo "Could not connect to database.<br>";
            echo "Error Number: ".mysqli_connect_errno()."<br>";
            echo "Error: ".mysqli_connect_error();
          }else {//if connect successful
            if (isset($_POST['bhg'])) {//check if there is data pass in
              $bhg = $_POST['bhg'];

              //decide which table to select
              if ($bhg == 0) {//if data pass from bahagian A
                $query = "SELECT * FROM bhgA";
              }elseif($bhg == 1){//if data pass from bahagian B
                $query = "SELECT * FROM bhgB";
              }else {//if data pass from bahagian c
                $query = "SELECT * FROM bhgC";
              }

              //check if query is success
              if (!mysqli_query($conn,$query)) {
                echo "Query unsuccessfull".mysqli_error();
                echo "Query: ".$query;

              }else {
                $choice = array();//to store options user entered
                $dataList = array();//to retrieve database
                $i = 0;

                $r = mysqli_query($conn,$query);//run this query
                //retrieve every row of data
                while ($row = mysqli_fetch_array($r)) {
                  //store every column
                  $dataList[$i] = array($row['quest_id'],//0
                                      $row['question'],//1
                                      $row['opt_1']   ,//2
                                      $row['opt_2']   ,//3
                                      $row['opt_3']   ,//4
                                      $row['ans'])    ;//5
                  $i++;
                }//end while
                $ttlQuest = $i;//number questions
                $ttlEmpty = 0;//see how many empty
                $ttlCorrect = 0;//accumulate how many correct
                //GET THE VALUES FROM THE FORM
                for ($k=0; $k <$ttlQuest ; $k++) {
                  $index = 'q'.($k+1);
                  if (empty($_POST[$index])) {
                    $choice[$k] = "<b>You did not answer this question</b>";
                    $ttlEmpty++;
                  }else {
                    $choice[$k] = $_POST[$index];//assign user answer
                    if ($choice[$k] == $dataList[$k][5]) {
                      $ttlCorrect++;//increase 1 if correct
                    }
                  }
                }
                //if all empty, go back to questions
                if ($ttlEmpty == $ttlQuest) {
                  $redirect = "Refresh:0; url=bhg.php?choose=".$bhg;
                  echo "<script>alert('Do not leave all questions empty')</script>";
                  header($redirect);
                }
                //decide result format based on Bahagian
                if ($bhg != 0) {//if bahagian B or C
                  echo ($bhg ==1)?"<h1>Result for Bahagian B</h1>":"<h1>Result for Bahagian C</h1>";
                  echo "<h3 style=\"color:grey\">Total answers correct: ".$ttlCorrect."</3>";
                  echo "<br><hr>";
                  for ($k=0; $k <$ttlQuest ; $k++) {
                    //if ans correct
                    if ($choice[$k] == $dataList[$k][5]) {
                      $ttlCorrect++;
                      echo "<h3 style=\"color:blue\">Question: ".$dataList[$k][1]."</h3>";
                      echo "<p>Your answer: ".$choice[$k]."</p>";
                      echo "<p style=\"color:green\">Status     : <b>CORRECT</b></p>";
                      echo "<hr>";
                    }
                    else {//if wrong
                      echo "<h3 style=\"color:blue\">Question: ".$dataList[$k][1]."</h3>";
                      echo "<p>Your answer   : ".$choice[$k]."</p>";
                      echo "<p style=\"color:red\">Status        : <b>INCORRECT</b></p>";
                      echo "<p>Correct answer: ".$dataList[$k][5]."</p>";
                      echo "<hr>";
                    }
                  }//end for loop
                }//end if ($bhg != 0)

                else {// else if bahagian A
                  echo "<h1>Result for Bahagian A</h1>";
                  echo "<h3 style=\"color:grey\">Total answers correct: ".$ttlCorrect."</3>";
                  echo "<br><hr>";
                  for ($k=0; $k <$ttlQuest ; $k++) {
                    //different display pattern for these questions
                    if ($k==9||$k==10||$k==11||$k==12||$k==13||$k==14||$k==23) {
                      //if ans correct
                      if ($choice[$k] == $dataList[$k][5]) {
                        $ttlCorrect++;
                        ?>
                        <h3 style="color:blue">Question: <?php echo $dataList[$k][1]; ?></h3>
                        <p>Your answer   :<img src="<?php echo $choice[$k]; ?>"></p>
                        <p style="color:green">Status     : <b>CORRECT<b></p>
                          <hr>
                        <?php
                      }
                      else {//if wrong
                        ?>
                        <h3 style="color:blue">Question: <?php echo $dataList[$k][1]; ?></h3>
                        <?php
                        if ($choice[$k] == "<b>You did not answer this question</b>") {
                          echo "<p>Your answer   :$choice[$k]</p>";
                        }else {
                        ?>
                        <p>Your answer   :<img src="<?php echo $choice[$k]; ?>"></p>
                        <?php
                        }//end else
                        ?>
                        <p style="color:red">Status        : INCORRECT</p>
                        <p>Correct answer: <img src="<?php echo $dataList[$k][5]; ?>"> </p>
                        <hr>
                        <?php
                      }
                    }//end if q10-q15,q24
                    else {//other questions in Bhg A
                      //get the image source to display
                      //10th-15th and 24th value in array is empty, because it will be taken from db
                      $img_src = array("images/a_set1_1.png","images/a_set1_2.png","images/a_set1_3.png","images/a_set1_4.png","images/a_set1_5.png",
                                      "images/a_set1_6.png","images/a_set1_7.png","images/a_set1_8.png","images/a_set1_9.png","","","","","","",
                                      "images/a_set1_16.png","images/a_set1_17.png","images/a_set1_18.png","images/a_set1_19.png","images/a_set1_20.png",
                                      "images/a_set1_21.png","images/a_set1_22.png","images/a_set1_23.png","","images/a_set1_25.png");
                      if ($choice[$k] == $dataList[$k][5]) {
                        $ttlCorrect++;
                        ?>
                        <h3 style="color:blue">Question: <?php echo $dataList[$k][1]; ?></h3>
                        <img src="<?php echo $img_src[$k] ?>">
                        <p>Your answer   : <?php echo $choice[$k]; ?></p>
                        <p style="color:green">Status     : CORRECT</p>
                        <hr>
                        <?php
                      }
                      else {//if wrong
                        ?>
                        <h3 style="color:blue">Question: <?php echo $dataList[$k][1]; ?></h3>
                        <img src="<?php echo $img_src[$k] ?>">
                        <p>Your answer   : <?php echo $choice[$k]; ?></p>
                        <p style="color:red">Status        : INCORRECT</p>
                        <p>Correct answer: <?php echo $dataList[$k][5]; ?></p>
                        <hr>
                        <?php
                      }
                    }
                  }//end for loop
                  echo "<br><br>";
                }//end else if bahagian A
              }//end if(!mysqli_query($conn,$query))-else
            }//end if (isset($_POST['bhg']))
          }
        mysqli_close($conn);
        ?>
      </div>
      <div class="col-md-5">

      </div>
    </div>
</body>
</html>
